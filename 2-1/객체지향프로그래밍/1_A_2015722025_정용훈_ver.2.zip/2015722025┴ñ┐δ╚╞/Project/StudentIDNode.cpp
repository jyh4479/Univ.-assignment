#include "StudentIDNode.h"



StudentIDNode::StudentIDNode()
{
}


StudentIDNode::~StudentIDNode()
{
}
