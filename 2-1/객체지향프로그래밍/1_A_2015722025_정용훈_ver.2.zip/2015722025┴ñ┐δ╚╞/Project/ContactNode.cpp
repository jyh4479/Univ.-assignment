#include "ContactNode.h"

ContactNode::ContactNode()
{
}


ContactNode::~ContactNode()
{
}
