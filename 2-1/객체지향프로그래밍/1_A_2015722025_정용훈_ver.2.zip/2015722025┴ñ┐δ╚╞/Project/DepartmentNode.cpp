#include "DepartmentNode.h"

DepartmentNode::DepartmentNode()
{
}

DepartmentNode::~DepartmentNode()
{
}