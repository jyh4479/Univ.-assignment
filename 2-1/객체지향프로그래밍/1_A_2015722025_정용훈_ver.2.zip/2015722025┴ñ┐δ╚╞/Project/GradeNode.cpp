#include "GradeNode.h"



GradeNode::GradeNode()
{
}


GradeNode::~GradeNode()
{
}
